Page({
  data: {
  },

  onLoad: function () {
  },
  loginBtn() {
    wx.redirectTo({
      url: "/pages/datapre/datapre",
    })
  }
})
