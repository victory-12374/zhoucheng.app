//index.js
Page({
  data: {
  },

  onLoad: function() {
  },
  navToPre(){
    wx.navigateTo({
      url: "/pages/login/login",
    })
  }
})
